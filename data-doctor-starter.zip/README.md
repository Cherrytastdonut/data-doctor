# Data Doctor AI

CSV 데이터를 검사하고 사용자가 선택한 규칙으로 정리한 뒤 수정된 CSV를 내려받는 웹서비스입니다.

## 현재 구현
- CSV 업로드 / 미리보기
- 결측값 탐지
- 완전 중복 행 탐지
- 앞뒤 공백 탐지
- 결측값 처리: 유지 / 행 삭제 / 최빈값 / 평균값 / 중앙값 / 직접 입력
- 중복 삭제
- 공백 제거
- 수정된 CSV 다운로드
- OpenAI API 기반 의미상 형식 불일치 분석
- Supabase에 작업 기록 저장 및 최근 기록 조회

## 플랫폼
- GitHub: 소스 관리
- Vercel: 정적 웹 + `/api` 서버 함수 배포
- Supabase: PostgreSQL 작업 기록 저장
- OpenAI API: AI 형식 분석
- Google Sheets API: 다음 단계에서 추가 예정

## Vercel 환경변수
Vercel Project → Settings → Environment Variables에서 설정하세요.

- `OPENAI_API_KEY` : Secret
- `OPENAI_MODEL` : Config, 선택사항. 기본값 `gpt-6-astra`
- `SUPABASE_URL` : Config
- `SUPABASE_SECRET_KEY` : Secret

환경변수를 추가/수정한 뒤 재배포해야 반영됩니다.

## Supabase
Supabase SQL Editor에서 `supabase.sql` 내용을 실행하세요.

브라우저에서 Supabase Secret Key를 사용하지 않습니다.
Vercel 서버 함수에서만 DB에 접근합니다.

## Vercel 배포
GitHub 저장소를 Vercel에서 Import합니다.

- Framework Preset: `Other`
- Build Command: 비워두기
- Output Directory: `.` 또는 기본값
- Root Directory: 저장소 루트

## 다음 단계
과제 필수 조건인 Google API를 충족하기 위해 Google Sheets API 가져오기/내보내기를 추가합니다.
