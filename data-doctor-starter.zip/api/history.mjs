function supabaseConfig() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SECRET_KEY;
  if (!url || !key) throw new Error("Supabase 환경변수가 설정되지 않았습니다.");
  return { url: url.replace(/\/$/, ""), key };
}

export default {
  async fetch(request) {
    if (request.method !== "GET") {
      return Response.json({ error: "GET만 허용됩니다." }, { status: 405 });
    }

    try {
      const { url, key } = supabaseConfig();

      const res = await fetch(
        `${url}/rest/v1/analysis_runs?select=id,file_name,original_rows,cleaned_rows,issue_count,actions,created_at&order=created_at.desc&limit=10`,
        {
          headers: {
            "apikey": key,
            "Authorization": `Bearer ${key}`
          }
        }
      );

      const rows = await res.json();
      if (!res.ok) {
        return Response.json({ error: rows?.message || "Supabase 조회 실패" }, { status: res.status });
      }

      return Response.json({ rows });
    } catch (error) {
      return Response.json({ error: error.message || "서버 오류" }, { status: 500 });
    }
  }
};
