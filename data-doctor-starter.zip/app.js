const state = {
  file: null,
  headers: [],
  rows: [],
  cleanedRows: [],
  analysis: null,
};

const $ = (id) => document.getElementById(id);

const NULL_LIKE = new Set(["", "-", "n/a", "na", "null", "none", "없음", "미입력", "unknown"]);

function isMissing(value) {
  if (value === null || value === undefined) return true;
  return NULL_LIKE.has(String(value).trim().toLowerCase());
}

function parseCSV(text) {
  const rows = [];
  let row = [];
  let field = "";
  let quoted = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i + 1];

    if (quoted) {
      if (c === '"' && next === '"') {
        field += '"';
        i++;
      } else if (c === '"') {
        quoted = false;
      } else {
        field += c;
      }
    } else {
      if (c === '"') quoted = true;
      else if (c === ",") {
        row.push(field);
        field = "";
      } else if (c === "\n") {
        row.push(field.replace(/\r$/, ""));
        rows.push(row);
        row = [];
        field = "";
      } else {
        field += c;
      }
    }
  }

  if (field.length || row.length) {
    row.push(field.replace(/\r$/, ""));
    rows.push(row);
  }

  while (rows.length && rows[rows.length - 1].every(v => String(v).trim() === "")) rows.pop();
  if (rows.length < 2) throw new Error("헤더와 데이터 행이 필요합니다.");

  const headers = rows[0].map((h, i) => String(h || `column_${i + 1}`).trim());
  const objects = rows.slice(1).map(values => {
    const obj = {};
    headers.forEach((h, i) => obj[h] = values[i] ?? "");
    return obj;
  });

  return { headers, rows: objects };
}

function csvEscape(value) {
  const s = value === null || value === undefined ? "" : String(value);
  if (/[",\n\r]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function toCSV(headers, rows) {
  const lines = [headers.map(csvEscape).join(",")];
  for (const row of rows) lines.push(headers.map(h => csvEscape(row[h])).join(","));
  return "\uFEFF" + lines.join("\r\n");
}

function normalizedRowKey(row) {
  return state.headers.map(h => String(row[h] ?? "").trim()).join("\u241F");
}

function numericValues(column) {
  return state.rows
    .map(r => r[column])
    .filter(v => !isMissing(v))
    .map(v => Number(String(v).replace(/,/g, "").trim()))
    .filter(Number.isFinite);
}

function statsFor(column) {
  const values = numericValues(column);
  if (!values.length) return null;
  const sorted = [...values].sort((a,b) => a-b);
  const avg = values.reduce((a,b)=>a+b,0)/values.length;
  const mid = Math.floor(sorted.length/2);
  const median = sorted.length % 2 ? sorted[mid] : (sorted[mid-1] + sorted[mid]) / 2;
  const counts = new Map();
  values.forEach(v => counts.set(v, (counts.get(v) || 0) + 1));
  let mode = values[0], modeCount = 0;
  for (const [v,c] of counts) if (c > modeCount) { mode = v; modeCount = c; }
  return { avg, median, mode, count: values.length };
}

function modeForText(column) {
  const counts = new Map();
  state.rows.forEach(r => {
    const v = String(r[column] ?? "").trim();
    if (!isMissing(v)) counts.set(v, (counts.get(v) || 0) + 1);
  });
  let mode = "", count = 0;
  for (const [v,c] of counts) if (c > count) { mode = v; count = c; }
  return mode;
}

function analyzeRows() {
  const missing = {};
  let whitespaceCount = 0;

  state.headers.forEach(h => missing[h] = 0);

  state.rows.forEach(row => {
    state.headers.forEach(h => {
      const raw = row[h];
      if (isMissing(raw)) missing[h]++;
      if (typeof raw === "string" && raw !== raw.trim()) whitespaceCount++;
    });
  });

  const seen = new Map();
  state.rows.forEach(row => {
    const key = normalizedRowKey(row);
    seen.set(key, (seen.get(key) || 0) + 1);
  });
  let duplicateRows = 0;
  for (const count of seen.values()) if (count > 1) duplicateRows += count - 1;

  let issueCount = duplicateRows + whitespaceCount + Object.values(missing).reduce((a,b)=>a+b,0);

  return { missing, whitespaceCount, duplicateRows, issueCount };
}

function renderTable(target, rows, limit = 100) {
  const table = $(target);
  table.innerHTML = "";

  const thead = document.createElement("thead");
  const hr = document.createElement("tr");
  ["#", ...state.headers].forEach(h => {
    const th = document.createElement("th");
    th.textContent = h;
    hr.appendChild(th);
  });
  thead.appendChild(hr);

  const tbody = document.createElement("tbody");
  rows.slice(0, limit).forEach((row, i) => {
    const tr = document.createElement("tr");
    const idx = document.createElement("td");
    idx.textContent = i + 1;
    tr.appendChild(idx);
    state.headers.forEach(h => {
      const td = document.createElement("td");
      td.textContent = row[h] ?? "";
      td.title = row[h] ?? "";
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  table.append(thead, tbody);
}

function renderIssues() {
  const a = state.analysis;
  const items = [];

  if (a.duplicateRows) items.push({
    title: `중복 행 ${a.duplicateRows}개`,
    desc: "모든 열 값이 같은 행을 중복으로 판단했습니다.",
    badge: "중복", cls: "danger"
  });

  if (a.whitespaceCount) items.push({
    title: `앞뒤 공백 ${a.whitespaceCount}개`,
    desc: "문자열 값의 시작 또는 끝에 불필요한 공백이 있습니다.",
    badge: "공백", cls: "warn"
  });

  for (const [col, count] of Object.entries(a.missing)) {
    if (count) items.push({
      title: `${col} 결측값 ${count}개`,
      desc: "빈칸, -, N/A, NULL, 없음 등을 결측값으로 탐지했습니다.",
      badge: "결측", cls: "warn"
    });
  }

  if (!items.length) items.push({
    title: "기본 검사에서 문제가 발견되지 않았습니다.",
    desc: "GPT 형식 분석을 실행하면 의미상 형식 불일치도 추가로 확인할 수 있습니다.",
    badge: "정상", cls: "good"
  });

  $("issues").innerHTML = `<div class="issue-list">${items.map(x => `
    <div class="issue-card">
      <div><strong>${escapeHtml(x.title)}</strong><p>${escapeHtml(x.desc)}</p></div>
      <span class="badge ${x.cls}">${x.badge}</span>
    </div>`).join("")}</div>`;

  $("issueCount").textContent = a.issueCount.toLocaleString();
}

function renderMissingControls() {
  const cols = Object.entries(state.analysis.missing).filter(([,count]) => count > 0);
  const root = $("missingControls");

  if (!cols.length) {
    root.innerHTML = "";
    return;
  }

  root.innerHTML = `<h3 class="missing-title">결측값 처리</h3><div class="missing-grid">${
    cols.map(([col,count], idx) => {
      const stats = statsFor(col);
      const textMode = modeForText(col);
      const options = [
        `<option value="keep">그대로 유지</option>`,
        `<option value="delete">결측값이 있는 행 삭제</option>`,
        `<option value="mode">최빈값으로 채우기${textMode !== "" ? ` (${escapeHtml(String(textMode))})` : ""}</option>`,
        `<option value="custom">직접 입력</option>`,
      ];
      if (stats && stats.count >= Math.max(2, Math.floor((state.rows.length-count)*0.6))) {
        options.splice(2, 0,
          `<option value="average">평균값으로 채우기 (${round(stats.avg)})</option>`,
          `<option value="median">중앙값으로 채우기 (${round(stats.median)})</option>`
        );
      }
      return `<div class="control-card">
        <label>${escapeHtml(col)} <span class="badge warn">${count}개</span></label>
        <select class="missing-action" data-column="${escapeAttr(col)}" data-custom="custom-${idx}">
          ${options.join("")}
        </select>
        <input class="custom-input" id="custom-${idx}" type="text" placeholder="채울 값을 입력하세요" />
        <small>숫자형으로 판단되는 열에는 평균·중앙값 옵션이 추가됩니다.</small>
      </div>`;
    }).join("")
  }</div>`;

  document.querySelectorAll(".missing-action").forEach(sel => {
    sel.addEventListener("change", () => {
      const input = $(sel.dataset.custom);
      input.style.display = sel.value === "custom" ? "block" : "none";
    });
  });
}

function round(n) {
  return Math.round(n * 100) / 100;
}

function applyCleaning() {
  let rows = state.rows.map(r => ({...r}));
  const actions = [];
  let changed = 0;

  if ($("trimAction").value === "trim") {
    rows.forEach(row => state.headers.forEach(h => {
      if (typeof row[h] === "string") {
        const next = row[h].trim();
        if (next !== row[h]) changed++;
        row[h] = next;
      }
    }));
    actions.push("앞뒤 공백 제거");
  }

  const missingSelections = [...document.querySelectorAll(".missing-action")].map(sel => ({
    column: sel.dataset.column,
    action: sel.value,
    customId: sel.dataset.custom
  }));

  for (const selection of missingSelections) {
    const { column, action, customId } = selection;
    if (action === "keep") continue;

    if (action === "delete") {
      const before = rows.length;
      rows = rows.filter(r => !isMissing(r[column]));
      changed += before - rows.length;
      actions.push(`${column}: 결측 행 삭제`);
      continue;
    }

    let fill;
    if (action === "mode") fill = modeFromRows(rows, column);
    if (action === "average" || action === "median") {
      const nums = rows
        .map(r => r[column])
        .filter(v => !isMissing(v))
        .map(v => Number(String(v).replace(/,/g, "").trim()))
        .filter(Number.isFinite);
      if (nums.length) {
        const sorted = [...nums].sort((a,b)=>a-b);
        if (action === "average") fill = round(nums.reduce((a,b)=>a+b,0)/nums.length);
        else {
          const m = Math.floor(sorted.length/2);
          fill = round(sorted.length%2 ? sorted[m] : (sorted[m-1]+sorted[m])/2);
        }
      }
    }
    if (action === "custom") fill = $(customId).value;

    if (fill !== undefined && fill !== "") {
      rows.forEach(r => {
        if (isMissing(r[column])) {
          r[column] = fill;
          changed++;
        }
      });
      actions.push(`${column}: ${action} 채우기`);
    }
  }

  if ($("duplicateAction").value === "remove") {
    const seen = new Set();
    const deduped = [];
    for (const row of rows) {
      const key = state.headers.map(h => String(row[h] ?? "").trim()).join("\u241F");
      if (!seen.has(key)) {
        seen.add(key);
        deduped.push(row);
      } else changed++;
    }
    rows = deduped;
    actions.push("중복 행 삭제");
  }

  state.cleanedRows = rows;
  renderTable("resultTable", rows);
  $("resultSummary").innerHTML = `
    <span class="pill">원본 ${state.rows.length.toLocaleString()}행</span>
    <span class="pill">결과 ${rows.length.toLocaleString()}행</span>
    <span class="pill">${changed.toLocaleString()}개 수정/삭제</span>
    <span class="pill">${actions.length}개 규칙 적용</span>`;
  $("resultPanel").classList.remove("hidden");

  saveRun({
    file_name: state.file?.name || "unknown.csv",
    original_rows: state.rows.length,
    cleaned_rows: rows.length,
    issue_count: state.analysis.issueCount,
    actions
  });
}

function modeFromRows(rows, column) {
  const counts = new Map();
  rows.forEach(r => {
    const v = String(r[column] ?? "").trim();
    if (!isMissing(v)) counts.set(v, (counts.get(v)||0)+1);
  });
  let best = "", count = 0;
  for (const [v,c] of counts) if (c > count) { best = v; count = c; }
  return best;
}

function downloadCleaned() {
  if (!state.cleanedRows.length) return;
  const blob = new Blob([toCSV(state.headers, state.cleanedRows)], {type:"text/csv;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const base = (state.file?.name || "data.csv").replace(/\.csv$/i,"");
  a.href = url;
  a.download = `${base}_cleaned.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

async function aiAnalyze() {
  const btn = $("aiAnalyzeBtn");
  const box = $("aiResult");
  btn.disabled = true;
  btn.textContent = "GPT 분석 중...";
  box.classList.remove("hidden");
  box.textContent = "열 이름과 일부 샘플만 전송하여 형식 불일치를 분석하고 있습니다.";

  const samples = {};
  state.headers.forEach(h => {
    samples[h] = state.rows.slice(0, 20).map(r => r[h]);
  });

  try {
    const res = await fetch("/api/analyze", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        fileName: state.file?.name,
        rowCount: state.rows.length,
        headers: state.headers,
        samples
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "AI 분석 실패");

    const suggestions = data.analysis?.suggestions || [];
    if (suggestions.length) {
      box.innerHTML = `<strong>GPT 형식 분석 결과</strong><div class="issue-list" style="margin-top:12px">${
        suggestions.map(s => `<div class="issue-card">
          <div>
            <strong>${escapeHtml(s.column || "열")}</strong>
            <p>${escapeHtml(s.problem || "")}<br/>추천: ${escapeHtml(s.recommendation || "")}</p>
          </div>
          <span class="badge warn">${escapeHtml(s.type || "AI")}</span>
        </div>`).join("")
      }</div>`;
    } else {
      box.textContent = data.raw || "추가 형식 문제가 발견되지 않았습니다.";
    }
  } catch (e) {
    box.textContent = `GPT 연결 오류: ${e.message}\nVercel의 OPENAI_API_KEY 환경변수를 확인해 주세요.`;
  } finally {
    btn.disabled = false;
    btn.textContent = "GPT로 형식 분석";
  }
}

async function saveRun(payload) {
  try {
    await fetch("/api/save-run", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    loadHistory();
  } catch (_) {}
}

async function loadHistory() {
  try {
    const res = await fetch("/api/history");
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "DB 오류");

    $("dbStatus").textContent = "Supabase 연결됨";
    $("history").innerHTML = data.rows?.length ? data.rows.map(r => `
      <div class="history-item">
        <strong>${escapeHtml(r.file_name)}</strong>
        <span>원본 ${Number(r.original_rows).toLocaleString()}행</span>
        <span>결과 ${Number(r.cleaned_rows).toLocaleString()}행</span>
        <span>문제 ${Number(r.issue_count).toLocaleString()}개</span>
        <span>${new Date(r.created_at).toLocaleString("ko-KR")}</span>
      </div>`).join("") : `<div class="empty">아직 저장된 작업이 없습니다.</div>`;
  } catch (e) {
    $("dbStatus").textContent = "Supabase 미연결";
    $("history").innerHTML = `<div class="empty">Supabase 환경변수/테이블을 연결하면 기록이 여기에 표시됩니다.</div>`;
  }
}

async function handleFile(file) {
  if (!file || !file.name.toLowerCase().endsWith(".csv")) {
    alert("현재 버전은 CSV 파일만 지원합니다.");
    return;
  }

  try {
    const text = await file.text();
    const parsed = parseCSV(text);
    state.file = file;
    state.headers = parsed.headers;
    state.rows = parsed.rows;
    state.cleanedRows = [];
    state.analysis = analyzeRows();

    $("fileName").textContent = file.name;
    $("rowCount").textContent = state.rows.length.toLocaleString();
    $("columnCount").textContent = state.headers.length.toLocaleString();
    $("uploadPanel").classList.add("hidden");
    $("workspace").classList.remove("hidden");
    $("resultPanel").classList.add("hidden");
    $("aiResult").classList.add("hidden");

    renderTable("previewTable", state.rows);
    renderIssues();
    renderMissingControls();
  } catch (e) {
    alert(`CSV를 읽지 못했습니다: ${e.message}`);
  }
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}
function escapeAttr(value) { return escapeHtml(value); }

$("fileInput").addEventListener("change", e => handleFile(e.target.files?.[0]));
$("resetBtn").addEventListener("click", () => location.reload());
$("applyBtn").addEventListener("click", applyCleaning);
$("downloadBtn").addEventListener("click", downloadCleaned);
$("aiAnalyzeBtn").addEventListener("click", aiAnalyze);
$("refreshHistoryBtn").addEventListener("click", loadHistory);

const dz = $("dropzone");
["dragenter","dragover"].forEach(type => dz.addEventListener(type, e => {
  e.preventDefault(); dz.classList.add("drag");
}));
["dragleave","drop"].forEach(type => dz.addEventListener(type, e => {
  e.preventDefault(); dz.classList.remove("drag");
}));
dz.addEventListener("drop", e => handleFile(e.dataTransfer.files?.[0]));

loadHistory();
